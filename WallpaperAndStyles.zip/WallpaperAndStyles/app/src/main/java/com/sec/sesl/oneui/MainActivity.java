package com.sec.sesl.oneui;

import android.R;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.view.MenuInflater;
import com.sec.sesl.oneui.R.menu;
import androidx.annotation.NonNull;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.Canvas;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import androidx.core.view.MenuCompat;
import dev.oneuiproject.oneui.widget.Toast;
import androidx.annotation.Nullable;
import android.app.WallpaperManager;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.media.projection.MediaProjection;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.Log;
import androidx.appcompat.app.AlertDialog;
import android.os.Handler;
import java.io.FileNotFoundException;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;
import com.sec.sesl.oneui.databinding.ActivityMainBinding;
import dev.oneuiproject.oneui.layout.ToolbarLayout;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;

    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Inflate and get instance of binding
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        // set content view to binding's root
        setContentView(binding.getRoot());
        binding.toolbarLayout.setNavigationButtonAsBack();
        binding.lockScreenPreview.setOnClickListener(
                v -> {
                    WallpaperManager walli = WallpaperManager.getInstance(this);
                    binding.lockScreenPreview.buildDrawingCache();
                    Bitmap bmap = binding.lockScreenPreview.getDrawingCache();
                    try {
                        walli.setBitmap(bmap, null, false, WallpaperManager.FLAG_LOCK);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
        binding.change.setOnClickListener(
                v -> {
                    startActivity(new Intent(this,Wallpapers.class));
                });
        binding.homeScreenPreview.setOnClickListener(
                v -> {
                    WallpaperManager walli = WallpaperManager.getInstance(this);
                    binding.homeScreenPreview.buildDrawingCache();
                    Bitmap bmap = binding.homeScreenPreview.getDrawingCache();
                    try {
                        walli.setBitmap(bmap, null, false, WallpaperManager.FLAG_SYSTEM);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
        binding.liveWallpaper.setOnClickListener(
                v -> {
                    startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
                });
        binding.phoneSettings.setOnClickListener(
                v -> {
                    Intent intent = new Intent();
                intent.setComponent(new ComponentName("com.samsung.android.app.homestar","com.samsung.android.app.homestar.SettingActivity"));
                try {
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(
                                        this,
                                        "Please install HomeUP app first",
                                        Toast.LENGTH_SHORT)
                                .show();
                    }
                });
        binding.goodLock.setOnClickListener(
                v -> {
                    startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS));
                });
        binding.homeset.setOnClickListener(
                v -> {
                    Intent intent = new Intent();
                    intent.setComponent(
                            new ComponentName(
                                    "com.sec.android.app.launcher",
                                    "com.android.homescreen.settings.HomeModeChangeActivity"));
                    startActivity(intent);
                });
        binding.palette.setOnClickListener(
                v -> {
                    Intent intent = new Intent();
                    intent.setComponent(
                            new ComponentName(
                                    "dev.kdrag0n.dyntheme",
                                    "dev.kdrag0n.dyntheme.ui.main.MainActivity"));
                    try {
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(
                                        this,
                                        "Please install Repainter app first",
                                        Toast.LENGTH_SHORT)
                                .show();
                    }
                });
    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        getMenuInflater().inflate(com.sec.sesl.oneui.R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == com.sec.sesl.oneui.R.id.action_about) {
            startActivity(new Intent(this, AboutActivity.class));
            return true;
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.binding = null;
    }
}
