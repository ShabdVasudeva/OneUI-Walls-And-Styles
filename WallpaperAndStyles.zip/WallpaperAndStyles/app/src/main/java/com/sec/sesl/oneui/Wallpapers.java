package com.sec.sesl.oneui;

import android.app.WallpaperManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.sec.sesl.oneui.databinding.LayoutWallpapersBinding;
import dev.oneuiproject.oneui.widget.Toast;
import java.io.IOException;

public class Wallpapers extends AppCompatActivity {
    private LayoutWallpapersBinding wall;
    private static final int PICK_IMAGE_REQUEST = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        wall = LayoutWallpapersBinding.inflate(getLayoutInflater());
        setContentView(wall.getRoot());
        wall.toolbar.setNavigationButtonAsBack();
        wall.feature1.setOnClickListener(
                v -> {
                    wall.feature1.buildDrawingCache();
                    Bitmap bmap = wall.feature1.getDrawingCache();
                    onWallpaperChange(bmap);
                });
        wall.feature2.setOnClickListener(
                v -> {
                    wall.feature2.buildDrawingCache();
                    Bitmap bmap = wall.feature2.getDrawingCache();
                    onWallpaperChange(bmap);
                });
        wall.feature3.setOnClickListener(
                v -> {
                    wall.feature3.buildDrawingCache();
                    Bitmap bmap = wall.feature3.getDrawingCache();
                    onWallpaperChange(bmap);
                });
        wall.feature5.setOnClickListener(
                v -> {
                    wall.feature5.buildDrawingCache();
                    Bitmap bmap = wall.feature5.getDrawingCache();
                    onWallpaperChange(bmap);
                });
        wall.feature6.setOnClickListener(
                v -> {
                    wall.feature6.buildDrawingCache();
                    Bitmap bmap = wall.feature6.getDrawingCache();
                    onWallpaperChange(bmap);
                });
        wall.graphic1.setOnClickListener(
                v -> {
                    wall.graphic1.buildDrawingCache();
                    Bitmap bmap = wall.graphic1.getDrawingCache();
                    onWallpaperChange(bmap);
                });
        wall.graphic2.setOnClickListener(
                v -> {
                    wall.graphic2.buildDrawingCache();
                    Bitmap bmap = wall.graphic2.getDrawingCache();
                    onWallpaperChange(bmap);
                });
        wall.graphic3.setOnClickListener(
                v -> {
                    wall.graphic3.buildDrawingCache();
                    Bitmap bmap = wall.graphic3.getDrawingCache();
                    onWallpaperChange(bmap);
                });
        wall.graphic4.setOnClickListener(
                v -> {
                    wall.graphic4.buildDrawingCache();
                    Bitmap bmap = wall.graphic4.getDrawingCache();
                    onWallpaperChange(bmap);
                });
        wall.gallery.setOnClickListener(v ->{
            openImagePicker();
        });
    }

    private void onWallpaperChange(Bitmap bom) {
        WallpaperManager walli = WallpaperManager.getInstance(this);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        // Set dialog properties
        builder.setTitle("Set wallpaper as")
                .setNegativeButton(
                        "Lockscreen",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                try {
                                    walli.setBitmap(bom, null, false, WallpaperManager.FLAG_LOCK);
                                    success();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                    fail();
                                }
                            }
                        })
                .setPositiveButton(
                        "Homescreen",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                try {
                                    walli.setBitmap(bom, null, false, WallpaperManager.FLAG_SYSTEM);
                                    success();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                    fail();
                                }
                            }
                        })
                .setNeutralButton(
                        "Both",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                try {
                                    walli.setBitmap(bom, null, false, WallpaperManager.FLAG_SYSTEM);
                                    walli.setBitmap(bom, null, false, WallpaperManager.FLAG_LOCK);
                                    success();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                    fail();
                                }
                            }
                        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
    private void openImagePicker() {
        // Use an Image Picker library to allow the user to select an image
        Intent pickImageIntent =
                new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickImageIntent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            // Set dialog properties
            builder.setTitle("Set wallpaper as")
                    .setNegativeButton(
                            "Lockscreen",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    setWallpaperLock(selectedImageUri);
                                }
                            })
                    .setPositiveButton(
                            "Homescreen",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    setWallpaper(selectedImageUri);
                                }
                            }).setNeutralButton("Both",new DialogInterface.OnClickListener(){
                                @Override
                                public void onClick(DialogInterface dialog, int which){
                                    setWallpaperBoth(selectedImageUri);
                                }
                            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
    }

    private void setWallpaper(Uri imageUri) {
        try {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
            wallpaperManager.setStream(
                    getContentResolver().openInputStream(imageUri),
                    null,
                    false,
                    WallpaperManager.FLAG_SYSTEM);
            Toast.makeText(this, "Wallpaper set successfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to set wallpaper", Toast.LENGTH_SHORT).show();
        }
    }

    private void setWallpaperLock(Uri imageUri) {
        try {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
            wallpaperManager.setStream(
                    getContentResolver().openInputStream(imageUri),
                    null,
                    false,
                    WallpaperManager.FLAG_LOCK);
            Toast.makeText(this, "Wallpaper set successfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to set wallpaper", Toast.LENGTH_SHORT).show();
        }
    }
    private void setWallpaperBoth(Uri imageUri) {
        try {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
            wallpaperManager.setStream(
                    getContentResolver().openInputStream(imageUri));
            Toast.makeText(this, "Wallpaper set successfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to set wallpaper", Toast.LENGTH_SHORT).show();
        }
    }
    private void success() {
        Toast.makeText(this, "Wallpaper set successfully", Toast.LENGTH_SHORT).show();
    }

    private void fail() {
        Toast.makeText(this, "Failed to set wallpaper", Toast.LENGTH_SHORT).show();
    }
}
