
plugins {
    id("com.android.application")
    
}
android {
    namespace = "com.sec.sesl.oneui"
    compileSdk = 33
    
    defaultConfig {
        applicationId = "com.sec.sesl.oneui"
        minSdk = 23
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
        
        vectorDrawables { 
            useSupportLibrary = true
        }
    }
    
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    buildFeatures {
        viewBinding = true
        
    }
    
}


dependencies {
    implementation("io.github.oneuiproject.sesl:appcompat:{version}")
    implementation("io.github.oneuiproject.sesl:apppickerview:{version}")
    implementation("io.github.oneuiproject.sesl:coordinatorlayout:{version}")
    implementation("io.github.oneuiproject.sesl:core:{version}")
    implementation("io.github.oneuiproject.sesl:customview:{version}")
    implementation("io.github.oneuiproject.sesl:drawerlayout:{version}")
    implementation("io.github.oneuiproject.sesl:fragment:{version}")
    implementation("io.github.oneuiproject.sesl:indexscroll:{version}")
    implementation("io.github.oneuiproject.sesl:material:{version}")
    implementation("io.github.oneuiproject.sesl:picker-basic:{version}")
    implementation("io.github.oneuiproject.sesl:picker-color:{version}")
    implementation("io.github.oneuiproject.sesl:preference:{version}")
    implementation("io.github.oneuiproject.sesl:recyclerview:{version}")
    implementation("io.github.oneuiproject.sesl:swiperefreshlayout:{version}")
    implementation("io.github.oneuiproject.sesl:viewpager:{version}")
    implementation("io.github.oneuiproject.sesl:viewpager2:{version}")
    implementation("io.github.oneuiproject:design:{version}")
    implementation("io.github.oneuiproject:icons:{version}")
    //implementation("io.github.oneuiproject:design:$lib_version")
}